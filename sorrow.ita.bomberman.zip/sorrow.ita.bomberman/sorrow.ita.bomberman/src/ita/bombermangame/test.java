/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ita.bombermangame;

/**
 *
 * @author MichaL
 */
public class test {
    
    public static void main(String[] args) {
        randomfield r = new randomfield();
        r.erzeugeRandomfield();
    }
}
