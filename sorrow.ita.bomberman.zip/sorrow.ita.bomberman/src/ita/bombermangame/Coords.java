/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ita.bombermangame;

/**
 *
 * @author ala_pascal,heindani,michael,karina
 */
public class Coords {
    private int x;
    private int y;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Coords(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
