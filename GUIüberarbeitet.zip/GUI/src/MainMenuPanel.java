
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author sorrow
 */
public class MainMenuPanel extends JPanel {

    private JButton jb1;        //private variablen für die Button
    private JButton jb2;
    private JButton jb3;
    private JButton jb4;
    JLabel label;

    public MainMenuPanel() {
        initComp();
        
    }

    private void initComp() {
        this.setLayout(new BorderLayout());
        ImageIcon ii1 = new ImageIcon(MainMenuPanel.class.getResource("titelbild.jpg")); //Bild jpg wird in die Gui geladen
        Image i1 = ii1.getImage();
        i1 = i1.getScaledInstance(480, 272, Image.SCALE_SMOOTH);  // Größe der Konsole, wo später alles ausgegeben wird
        ii1.setImage(i1);
        JLabel bg = new JLabel(ii1);

        this.add(bg);

        jb2 = new javax.swing.JButton();    //Button erstellen
        jb3 = new javax.swing.JButton();
        jb1 = new javax.swing.JButton();
        jb4 = new javax.swing.JButton();

        jb2.setText("Einstellungen");       //Namen der Button
        jb3.setText("Beenden");
        jb1.setText("Spiel starten");
        jb4.setText("Hilfe");

        jb1.setBounds(160, 60, 150, 50);    // Größe, position der Button 
        jb2.setBounds(185, 143, 105, 30);
        jb4.setBounds(185, 173, 105, 30);
        jb3.setBounds(185, 203, 105, 30);
        
        jb1.setForeground(Color.WHITE);    // Schriftfarbe des Button auf weiß setzten
        jb2.setForeground(Color.WHITE);
        jb4.setForeground(Color.WHITE);
        jb3.setForeground(Color.white);

        jb1.setBackground(Color.BLACK); // Buttonfarbe auf schwarz setzen
        jb2.setBackground(Color.BLACK);
        jb4.setBackground(Color.BLACK);
        jb3.setBackground(Color.BLACK);
      
        bg.add(jb1);    // Fügt ein Objekt an der angegebenen Stelle in die Liste ein
        bg.add(jb2);
        bg.add(jb3);
        bg.add(jb4);
        
//        jb4.addActionListener((es)->{
//             
//            });
        jb3.addActionListener((e) -> {  // bei Betätigung des Button jb3 "Beenden" wird das Programm beendet
            System.exit(0);
        });

    }
     public void actionPerformed (ActionEvent es){
         JFrame frame = new JFrame("test");
         frame.setVisible(true);
         frame.setSize(480,272);
         JLabel label = new JLabel("klappt");
         JPanel panel = new JPanel();
         
         frame.add(panel);
         panel.add(label);

}
}